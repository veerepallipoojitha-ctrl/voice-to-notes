const SpeechRecognition =
    window.SpeechRecognition ||
    window.webkitSpeechRecognition;

let recognition;

let finalTranscript = "";


if (SpeechRecognition) {

    recognition = new SpeechRecognition();

    recognition.continuous = true;

    recognition.interimResults = true;

    recognition.lang = "en-US";


    recognition.onstart = function () {

        document.getElementById("status").innerText =
            "🎤 Recording... Speak your notes.";

    };


    recognition.onresult = function (event) {

        let interimTranscript = "";

        for (
            let i = event.resultIndex;
            i < event.results.length;
            i++
        ) {

            const transcript =
                event.results[i][0].transcript;


            if (event.results[i].isFinal) {

                finalTranscript +=
                    transcript + " ";

            }
            else {

                interimTranscript += transcript;

            }

        }


        document.getElementById("notes").value =
            finalTranscript + interimTranscript;

    };


    recognition.onerror = function (event) {

        document.getElementById("status").innerText =
            "Error: " + event.error;

    };


    recognition.onend = function () {

        document.getElementById("status").innerText =
            "Recording stopped.";

    };

}


function startRecognition() {

    if (!recognition) {

        alert(
            "Speech recognition is not supported. Please use Google Chrome."
        );

        return;

    }


    finalTranscript =
        document.getElementById("notes").value;


    try {

        recognition.start();

    }
    catch (error) {

        console.log(error);

    }

}


function stopRecognition() {

    if (recognition) {

        try {

            recognition.stop();

        }
        catch (error) {

            console.log(error);

        }

    }

}


function copyNotes() {

    const notes =
        document.getElementById("notes").value;


    if (notes.trim() === "") {

        alert("There are no notes to copy.");

        return;

    }


    navigator.clipboard.writeText(notes);

    document.getElementById("savedMessage").innerText =
        "✅ Notes copied to clipboard.";

}


function downloadNotes() {

    const notes =
        document.getElementById("notes").value;


    if (notes.trim() === "") {

        alert("There are no notes to download.");

        return;

    }


    const blob =
        new Blob([notes], {
            type: "text/plain"
        });


    const url =
        URL.createObjectURL(blob);


    const link =
        document.createElement("a");


    link.href = url;

    link.download = "voice-notes.txt";

    link.click();


    URL.revokeObjectURL(url);

}


function saveNotes() {

    const notes =
        document.getElementById("notes").value;


    localStorage.setItem(
        "voiceNotes",
        notes
    );


    document.getElementById("savedMessage").innerText =
        "✅ Notes saved in your browser.";

}


function clearNotes() {

    document.getElementById("notes").value = "";

    finalTranscript = "";

    document.getElementById("savedMessage").innerText = "";

}